#javac interfaces/*.java registry/*.java serverSide/*.java clientSide/*.java
#############Interfaces##############
cp interfaces/RegisterInterface.class dir_registry/interfaces/
cp interfaces/*.class dir_serverSide/interfaces/
cp interfaces/*.class dir_clientSide/interfaces/
cp interfaces/AssaultPartyInterface.class dir_clientSide/clientSide/
cp interfaces/ConcentrationSiteInterface.class dir_clientSide/clientSide/
cp interfaces/ControlCollectionSiteInterface.class dir_clientSide/clientSide/
cp interfaces/LoggerInterface.class dir_clientSide/clientSide/
cp interfaces/MuseumInterface.class dir_clientSide/clientSide/
#####################################
cp registry/*.class dir_registry/registry/
#####################################
cp serverSide/*.class dir_serverSide/serverSide/
cp clientSide/*.class dir_clientSide/clientSide/
cp AuxDataStructs/*.class dir_serverSide/AuxDataStructs/
cp AuxDataStructs/*.class dir_clientSide/AuxDataStructs/
cp AuxDataStructs/*.class dir_registry/AuxDataStructs/
cp AuxDataStructs/Logging/*.class dir_serverSide/AuxDataStructs/Logging/
mkdir -p /home/sd0306/Public/classes
mkdir -p /home/sd0306/Public/classes/interfaces
mkdir -p /home/sd0306/Public/classes/clientSide
cp interfaces/*.class /home/sd0306/Public/classes/interfaces
cp clientSide/*.class /home/sd0306/Public/classes/clientSide
cp set_rmiregistry.sh /home/sd0306
#cp set_rmiregistry_alt.sh /home/sd0306
#################Softlink###############
ln -s /var/www/html/sd0306/ ~/Public/