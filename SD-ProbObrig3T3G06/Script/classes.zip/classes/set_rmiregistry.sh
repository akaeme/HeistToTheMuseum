rmiregistry -J-Djava.rmi.server.codebase="http://${1}/sd0306/classes/"\
            -J-Djava.rmi.server.useCodebaseOnly=true $2
