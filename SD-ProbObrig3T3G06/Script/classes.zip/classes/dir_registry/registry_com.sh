java -Djava.rmi.server.codebase="http://${1}/sd0306/classes/"\
     -Djava.rmi.server.useCodebaseOnly=false\
     -Djava.security.policy=java.policy\
     registry.ServerRegisterRemoteObject $2