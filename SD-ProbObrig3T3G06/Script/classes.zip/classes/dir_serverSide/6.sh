java -Djava.rmi.server.codebase="http://${1}/sd0306/classes/"\
     -Djava.rmi.server.useCodebaseOnly=true\
     -Djava.security.policy=java.policy\
     serverSide.ServerAssaultParty_1 $2
 